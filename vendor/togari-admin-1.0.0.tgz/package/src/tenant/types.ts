/**
 * @togari/admin — Tenant types
 */

export interface TenantContext {
  /** Auth0 org_id — the primary tenant identifier */
  tenantId: string;
  /** Auth0 user sub — identifies the individual user */
  userId?: string;
  /** User email for audit logging */
  userEmail?: string;
  /** Subscription tier — determines rate limits and quotas */
  tier: 'free' | 'pro' | 'enterprise';
}
