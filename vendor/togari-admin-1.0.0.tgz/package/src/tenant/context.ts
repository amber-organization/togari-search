/**
 * @togari/admin — Tenant context using AsyncLocalStorage
 *
 * HTTP mode: Auth0 JWT → extract org_id → AsyncLocalStorage
 * stdio mode: TENANT_ID env var → module-level fallback
 */

import { AsyncLocalStorage } from 'node:async_hooks';
import type { TenantContext } from './types';

export const tenantStorage = new AsyncLocalStorage<TenantContext>();

let _stdioFallbackCtx: TenantContext | null = null;

export function setStdioFallback(ctx: TenantContext): void {
  _stdioFallbackCtx = ctx;
}

export function getCurrentTenant(): TenantContext {
  const ctx = tenantStorage.getStore();
  if (ctx) return ctx;
  if (_stdioFallbackCtx) return _stdioFallbackCtx;
  throw new Error(
    'No tenant context available. ' +
    'Ensure the request passed through tenant middleware (HTTP) or ' +
    'createStdioTenantContext() was used (stdio).'
  );
}

export function createStdioTenantContext(): TenantContext {
  const tenantId = process.env.TENANT_ID;
  if (!tenantId) {
    throw new Error(
      'TENANT_ID environment variable is required in stdio mode. ' +
      'Set it in your Claude Desktop config or shell environment.'
    );
  }

  const tier = (process.env.TENANT_TIER || 'free') as TenantContext['tier'];
  if (!['free', 'pro', 'enterprise'].includes(tier)) {
    throw new Error(`Invalid TENANT_TIER: "${tier}". Must be one of: free, pro, enterprise`);
  }

  return {
    tenantId,
    userId: process.env.USER_ID,
    userEmail: process.env.USER_EMAIL,
    tier,
  };
}
