export {
  createAuthMiddleware,
  oauthProtectedResourceHandler,
  oauthDiscoveryHandler,
} from './jwt';
