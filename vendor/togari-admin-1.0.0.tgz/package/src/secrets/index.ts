export { getSecret, getOptionalSecret, staticConfig, type StaticConfig } from './manager';
export * from './known-secrets';
