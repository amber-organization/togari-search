/**
 * @togari/admin — Cloud Run admin service
 *
 * Provides admin endpoints (health, audit queries, tenant management)
 * alongside the shared library exports.
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createLogger } from './observability/logger';
import { initSentry, flushSentry } from './observability/sentry';
import { oauthProtectedResourceHandler, oauthDiscoveryHandler } from './auth/jwt';
import { connectorRegistry } from './resilience/connector-registry';

const logger = createLogger('togari-admin');

async function main() {
  await initSentry();

  const app = express();
  app.use(helmet());
  app.use(cors());
  app.use(express.json());

  // OAuth discovery (public)
  app.get('/.well-known/oauth-protected-resource', oauthProtectedResourceHandler);
  app.get('/.well-known/oauth-authorization-server', oauthDiscoveryHandler);

  // Health check
  app.get('/health', (_req, res) => {
    const statuses = connectorRegistry.getAllStatuses();
    const allHealthy = statuses.length === 0 || statuses.every((s) => s.healthy);
    res.status(allHealthy ? 200 : 503).json({
      status: allHealthy ? 'healthy' : 'degraded',
      connectors: statuses,
      timestamp: new Date().toISOString(),
    });
  });

  // Admin endpoints (would be auth-protected in production)
  app.get('/admin/status', (_req, res) => {
    res.json({
      service: '@togari/admin',
      version: '1.0.0',
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      connectors: connectorRegistry.getAllStatuses(),
    });
  });

  const port = parseInt(process.env.PORT || '4000', 10);
  app.listen(port, () => {
    logger.info(`togari-admin service listening on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    logger.info('Shutting down...');
    await flushSentry();
    process.exit(0);
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
