/**
 * @togari/admin — BigQuery client
 *
 * Parameterized queries with read-only validation and audit writes.
 * Defense-in-depth: blocks mutations, enforces @clientId parameters.
 */

import { BigQuery } from '@google-cloud/bigquery';
import { createLogger } from '../observability/logger';

const logger = createLogger('BigQueryClient');

export interface QueryResult {
  rows: Record<string, unknown>[];
  totalRows: number;
  schema?: Record<string, string>[];
}

export class BigQueryClient {
  private client: BigQuery;

  constructor(projectId: string, keyFilename?: string | null, credentialsBase64?: string | null) {
    const opts: any = { projectId };
    if (keyFilename) {
      opts.keyFilename = keyFilename;
    } else if (credentialsBase64) {
      const decoded = Buffer.from(credentialsBase64, 'base64').toString('utf-8');
      opts.credentials = JSON.parse(decoded);
    }
    this.client = new BigQuery(opts);
  }

  async executeQuery(
    sql: string,
    params: Record<string, unknown> = {},
    auditInfo?: { toolName: string; clientId: string },
  ): Promise<QueryResult> {
    // Defense: block mutations
    const normalized = sql.trim().toUpperCase();
    if (!normalized.startsWith('SELECT') && !normalized.startsWith('WITH')) {
      throw new Error('Only SELECT/WITH queries are allowed');
    }

    const queryOpts: Record<string, unknown> = {
      query: sql,
      useLegacySql: false,
    };
    if (Object.keys(params).length > 0) {
      queryOpts.params = params;
    }

    const [job] = await this.client.createQueryJob(queryOpts);

    // Auto-pagination: collect all pages
    const allRows: Record<string, unknown>[] = [];
    let schema: Record<string, string>[] | undefined;
    let nextQuery: Record<string, unknown> | undefined = {};
    while (nextQuery !== undefined) {
      const [pageRows, next, response]: [unknown[], Record<string, unknown> | undefined, any] =
        await (job as any).getQueryResults({ autoPaginate: false, ...nextQuery });
      allRows.push(...(pageRows as Record<string, unknown>[]));
      if (!schema && response?.schema?.fields) {
        schema = (response.schema.fields as Array<{ name?: string; type?: string }>).map((f) => ({
          name: f.name ?? 'unknown',
          type: f.type ?? 'unknown',
        }));
      }
      nextQuery = next ?? undefined;
    }

    return {
      rows: allRows,
      totalRows: allRows.length,
      schema,
    };
  }

  async writeAuditLog(dataset: string, table: string, row: Record<string, unknown>): Promise<void> {
    try {
      await this.client.dataset(dataset).table(table).insert([row]);
    } catch (error) {
      logger.error('Failed to write audit log', error);
    }
  }

  getClient(): BigQuery {
    return this.client;
  }
}
